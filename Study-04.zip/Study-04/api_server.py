#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Google AI Studio (Gemini API) Server
- Unified Model: gemini-2.0-flash
- Image Analysis + Recipe Generation in one call
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
import json
import base64
import os
from pathlib import Path

# Load API Key from .env.txt
env_path = Path(__file__).parent / '.env.txt'
if env_path.exists():
    API_KEY = env_path.read_text().strip()
else:
    API_KEY = os.getenv('GOOGLE_API_KEY', '')

if not API_KEY:
    raise ValueError("API key not found in .env.txt or GOOGLE_API_KEY environment variable")

# Flask app setup
app = Flask(__name__)
CORS(app)

# Google AI Studio (Gemini) Configuration
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"
GEMINI_MODEL = "gemini-2.0-flash"


@app.route('/', methods=['GET'])
def index():
    """Serve the main web UI"""
    html_path = Path(__file__).parent / 'index.html'
    if html_path.exists():
        with open(html_path, 'r', encoding='utf-8') as f:
            html_content = f.read()
        return html_content
    else:
        return jsonify({
            'error': 'index.html not found'
        }), 404


@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'ok',
        'api_provider': 'Google AI Studio',
        'api_key_loaded': bool(API_KEY),
        'unified_model': GEMINI_MODEL
    }), 200


@app.route('/api/analyze-fridge', methods=['POST'])
def analyze_fridge():
    """
    Unified endpoint: Analyze fridge image and generate recipes in one call
    Using gemini-2.0-flash model for both tasks

    Request: multipart/form-data
    - image: File (이미지 파일)
    - preferences: JSON string (선택사항)
      {
        "difficulty": "쉬움/중간/어려움",
        "time": "15분/30분/60분+",
        "cuisine": "한식/양식/아시안/기타"
      }
    """
    try:
        # 이미지 파일 확인
        if 'image' not in request.files:
            return jsonify({
                'success': False,
                'error': 'Missing required field: image'
            }), 400

        image_file = request.files['image']

        if image_file.filename == '':
            return jsonify({
                'success': False,
                'error': 'No image file selected'
            }), 400

        # 이미지를 base64로 변환
        image_data = image_file.read()
        base64_image = base64.b64encode(image_data).decode('utf-8')

        # 파일 타입 결정
        filename = image_file.filename.lower()
        if filename.endswith(('.jpg', '.jpeg')):
            media_type = 'image/jpeg'
        elif filename.endswith('.png'):
            media_type = 'image/png'
        elif filename.endswith('.gif'):
            media_type = 'image/gif'
        elif filename.endswith('.webp'):
            media_type = 'image/webp'
        else:
            media_type = 'image/jpeg'

        # 사용자 선호도 파싱
        preferences = {}
        if 'preferences' in request.form:
            try:
                preferences = json.loads(request.form['preferences'])
            except:
                preferences = {}

        # 프롬프트 구성
        difficulty = preferences.get('difficulty', '중간')
        time_limit = preferences.get('time', '30분')
        cuisine = preferences.get('cuisine', '한식')

        prompt = f"""You are a professional chef analyzing a refrigerator image.

TASK:
1. First, identify ALL visible food items in the image and estimate their quantities
2. Then, generate 3 different recipes using these ingredients

REQUIREMENTS:
- Difficulty level: {difficulty}
- Cooking time: {time_limit}
- Cuisine type: {cuisine}

FORMAT YOUR RESPONSE AS JSON:
{{
  "ingredients_found": [
    {{"name": "재료명", "quantity": "수량", "freshness": "신선/약간상한/상한", "category": "카테고리"}},
    ...
  ],
  "recipes": [
    {{
      "title": "레시피명",
      "difficulty": "{difficulty}",
      "cooking_time": "XX분",
      "servings": "N인",
      "ingredients_used": ["재료1", "재료2"],
      "ingredients_needed": ["추가필요재료"],
      "instructions": [
        "1. 단계1",
        "2. 단계2",
        ...
      ],
      "nutrition": {{
        "calories": "XkcalXkcal",
        "protein": "Xg",
        "carbs": "Xg",
        "fat": "Xg"
      }},
      "tips": ["팁1", "팁2"],
      "rating": 4.5
    }},
    ...
  ]
}}

IMPORTANT:
- Be creative and practical with recipes
- Use actual ingredient names clearly
- Provide complete instructions
- Format as valid JSON only, no additional text"""

        # Gemini API 요청 구성
        payload = {
            "contents": [
                {
                    "parts": [
                        {
                            "inline_data": {
                                "mime_type": media_type,
                                "data": base64_image
                            }
                        },
                        {
                            "text": prompt
                        }
                    ]
                }
            ],
            "generationConfig": {
                "maxOutputTokens": 2000,
                "temperature": 0.7
            }
        }

        # Gemini API 호출
        headers = {
            "Content-Type": "application/json"
        }

        url = f"{GEMINI_API_URL}?key={API_KEY}"

        # Debug logging
        print(f"\n[DEBUG] API Call:")
        print(f"  URL: {url[:80]}...")
        print(f"  API Key: {API_KEY[:20]}...{API_KEY[-10:]}")
        print(f"  Payload size: {len(json.dumps(payload))} bytes")

        response = requests.post(
            url,
            headers=headers,
            json=payload,
            timeout=60
        )

        print(f"  Response Status: {response.status_code}")

        if response.status_code == 200:
            result = response.json()

            # Gemini API 응답에서 텍스트 추출
            try:
                response_text = result['candidates'][0]['content']['parts'][0]['text']
            except (KeyError, IndexError, TypeError):
                return jsonify({
                    'success': False,
                    'error': 'Unexpected response format from Gemini API',
                    'raw_response': result
                }), 500

            # 응답을 JSON으로 파싱 시도
            try:
                # JSON 부분만 추출
                json_start = response_text.find('{')
                json_end = response_text.rfind('}') + 1

                if json_start != -1 and json_end > json_start:
                    json_str = response_text[json_start:json_end]
                    parsed_data = json.loads(json_str)
                else:
                    parsed_data = {"raw_response": response_text}
            except json.JSONDecodeError:
                parsed_data = {"raw_response": response_text}

            return jsonify({
                'success': True,
                'model': GEMINI_MODEL,
                'api_provider': 'Google AI Studio',
                'ingredients_found': parsed_data.get('ingredients_found', []),
                'recipes': parsed_data.get('recipes', []),
                'raw_response': parsed_data.get('raw_response', response_text),
                'usage': {
                    'input_tokens': result.get('usageMetadata', {}).get('promptTokenCount', 'N/A'),
                    'output_tokens': result.get('usageMetadata', {}).get('candidatesTokenCount', 'N/A'),
                    'total_tokens': result.get('usageMetadata', {}).get('totalTokenCount', 'N/A')
                }
            }), 200
        else:
            # 오류 응답 처리
            try:
                error_data = response.json()
                error_msg = error_data.get('error', {}).get('message', 'Unknown error')
            except:
                error_msg = response.text

            return jsonify({
                'success': False,
                'error': error_msg,
                'status_code': response.status_code,
                'api_provider': 'Google AI Studio'
            }), response.status_code

    except requests.Timeout:
        return jsonify({
            'success': False,
            'error': 'Request timeout - Gemini API did not respond in time'
        }), 504
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/models', methods=['GET'])
def get_models():
    """Get available models"""
    return jsonify({
        'unified_model': GEMINI_MODEL,
        'description': 'Single model for image analysis and recipe generation',
        'api_provider': 'Google AI Studio',
        'capabilities': ['image_analysis', 'recipe_generation']
    }), 200


@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({
        'success': False,
        'error': 'Endpoint not found',
        'available_endpoints': {
            'GET': ['/health', '/api/models'],
            'POST': ['/api/analyze-fridge']
        }
    }), 404


if __name__ == '__main__':
    print("\n" + "="*70)
    print("Google AI Studio (Gemini) API Server")
    print("="*70)
    print(f"API Key loaded: {bool(API_KEY)}")
    print(f"API Provider: Google AI Studio")
    print(f"Unified Model: {GEMINI_MODEL}")
    print("\nStarting server on http://localhost:5000")
    print("\nAvailable Endpoints:")
    print("  - GET  /")
    print("  - GET  /health")
    print("  - GET  /api/models")
    print("  - POST /api/analyze-fridge (이미지 분석 + 레시피 생성)")
    print("="*70 + "\n")

    app.run(debug=True, host='0.0.0.0', port=5000)
