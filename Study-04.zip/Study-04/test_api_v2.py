#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import json
import os
from pathlib import Path

# API 키 로드
API_KEY = "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"
API_URL = "https://api.together.xyz/v1/chat/completions"

def test_text_generation():
    """qwen/qwen3.6-plus:free 모델로 텍스트 생성 테스트"""
    print("\n" + "="*70)
    print("[TEST 1] Text Generation (qwen/qwen3.6-plus:free)")
    print("="*70)

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": "qwen/qwen3.6-plus:free",
        "messages": [
            {
                "role": "user",
                "content": "What is artificial intelligence? Please explain it briefly in English."
            }
        ],
        "max_tokens": 500,
        "temperature": 0.7
    }

    try:
        print("\nRequest Details:")
        print(f"  - Model: qwen/qwen3.6-plus:free")
        print(f"  - Prompt: 'What is artificial intelligence? Please explain it briefly.'")
        print(f"  - Max tokens: 500")
        print(f"  - Temperature: 0.7")

        response = requests.post(API_URL, headers=headers, json=payload, timeout=30)
        print(f"\nResponse Status: {response.status_code}")

        if response.status_code == 200:
            result = response.json()
            content = result['choices'][0]['message']['content']

            print("\n[SUCCESS] Text Generation Test Passed!")
            print("\nGenerated Text:")
            print("-" * 70)
            print(content)
            print("-" * 70)

            # Additional info
            usage = result.get('usage', {})
            print(f"\nGeneration Info:")
            print(f"  - Input tokens: {usage.get('prompt_tokens', 'N/A')}")
            print(f"  - Output tokens: {usage.get('completion_tokens', 'N/A')}")
            print(f"  - Total tokens: {usage.get('total_tokens', 'N/A')}")
            print(f"  - Model: {result.get('model', 'N/A')}")

            return True

        else:
            print(f"[FAILED] Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return False

    except Exception as e:
        print(f"[ERROR] Exception: {str(e)}")
        return False


def test_image_recognition():
    """google/gemma-3-27b-it:free 모델로 이미지 인식 테스트"""
    print("\n" + "="*70)
    print("[TEST 2] Image Recognition (google/gemma-3-27b-it:free)")
    print("="*70)

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    # 테스트용 공개 이미지 URL
    image_url = "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Good_Food_Display_-_NCI_Visuals_Online.jpg/1024px-Good_Food_Display_-_NCI_Visuals_Online.jpg"

    payload = {
        "model": "google/gemma-3-27b-it:free",
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": image_url
                        }
                    },
                    {
                        "type": "text",
                        "text": "What can you see in this image? Please list all the food items visible in the image."
                    }
                ]
            }
        ],
        "max_tokens": 500,
        "temperature": 0.7
    }

    try:
        print("\nRequest Details:")
        print(f"  - Model: google/gemma-3-27b-it:free")
        print(f"  - Image: Wikipedia food image (public)")
        print(f"  - Question: 'What can you see in this image? Please list all food items.'")
        print(f"  - Max tokens: 500")
        print(f"  - Temperature: 0.7")

        response = requests.post(API_URL, headers=headers, json=payload, timeout=30)
        print(f"\nResponse Status: {response.status_code}")

        if response.status_code == 200:
            result = response.json()
            content = result['choices'][0]['message']['content']

            print("\n[SUCCESS] Image Recognition Test Passed!")
            print("\nImage Recognition Result:")
            print("-" * 70)
            print(content)
            print("-" * 70)

            # Additional info
            usage = result.get('usage', {})
            print(f"\nRecognition Info:")
            print(f"  - Input tokens: {usage.get('prompt_tokens', 'N/A')}")
            print(f"  - Output tokens: {usage.get('completion_tokens', 'N/A')}")
            print(f"  - Total tokens: {usage.get('total_tokens', 'N/A')}")
            print(f"  - Model: {result.get('model', 'N/A')}")

            return True

        else:
            print(f"[FAILED] Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return False

    except Exception as e:
        print(f"[ERROR] Exception: {str(e)}")
        return False


def test_image_with_base64():
    """Base64 이미지로 테스트 (선택사항)"""
    print("\n" + "="*70)
    print("[TEST 3] Image Recognition with Base64 Image")
    print("="*70)

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    # 간단한 빨간 픽셀 PNG 이미지 (Base64)
    red_pixel_base64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/8/wHwAFBQIAX8jx0gAAAABJRU5ErkJggg=="

    payload = {
        "model": "google/gemma-3-27b-it:free",
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/png;base64,{red_pixel_base64}"
                        }
                    },
                    {
                        "type": "text",
                        "text": "What color is this image?"
                    }
                ]
            }
        ],
        "max_tokens": 200,
        "temperature": 0.7
    }

    try:
        print("\nRequest Details:")
        print(f"  - Model: google/gemma-3-27b-it:free")
        print(f"  - Image: Base64 encoded test image")
        print(f"  - Question: 'What color is this image?'")
        print(f"  - Max tokens: 200")

        response = requests.post(API_URL, headers=headers, json=payload, timeout=30)
        print(f"\nResponse Status: {response.status_code}")

        if response.status_code == 200:
            result = response.json()
            content = result['choices'][0]['message']['content']

            print("\n[SUCCESS] Base64 Image Test Passed!")
            print(f"\nResponse: {content}")

            return True

        else:
            print(f"[FAILED] Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return False

    except Exception as e:
        print(f"[ERROR] Exception: {str(e)}")
        return False


def main():
    print("\n" + "="*70)
    print("TOGETHER AI API TEST SUITE")
    print("="*70)
    print(f"\nAPI Key: {API_KEY[:20]}...{API_KEY[-20:]}")
    print(f"API Endpoint: {API_URL}")

    # Run tests
    results = {}
    results['text_generation'] = test_text_generation()
    results['image_recognition'] = test_image_recognition()
    results['base64_image'] = test_image_with_base64()

    # Summary
    print("\n" + "="*70)
    print("TEST SUMMARY")
    print("="*70)

    passed = sum(1 for v in results.values() if v)
    total = len(results)

    for test_name, result in results.items():
        status = "[PASS]" if result else "[FAIL]"
        print(f"  {status} {test_name}")

    print(f"\nTotal: {passed}/{total} tests passed")
    print("="*70 + "\n")

    return all(results.values())


if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)
