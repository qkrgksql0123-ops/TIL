import requests
import base64
import json
from pathlib import Path
import sys
import io

# 한글 출력을 위한 인코딩 설정
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# Together AI API 설정
API_KEY = "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"
API_URL = "https://api.together.xyz/v1/chat/completions"

# 테스트 함수들

def test_text_generation():
    """qwen/qwen3.6-plus:free 모델로 텍스트 생성 테스트"""
    print("\n" + "="*60)
    print("[TEST 1] 텍스트 생성 (qwen/qwen3.6-plus:free)")
    print("="*60)

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    data = {
        "model": "qwen/qwen3.6-plus:free",
        "messages": [
            {
                "role": "user",
                "content": "안녕하세요. 인공지능이 뭐예요? 간단하게 설명해 주세요."
            }
        ],
        "max_tokens": 500,
        "temperature": 0.7
    }

    try:
        print("\n요청 정보:")
        print(f"  - 모델: qwen/qwen3.6-plus:free")
        print(f"  - 프롬프트: '안녕하세요. 인공지능이 뭐예요? 간단하게 설명해 주세요.'")
        print(f"  - Max tokens: 500")

        response = requests.post(API_URL, headers=headers, json=data, timeout=30)

        print(f"\n응답 상태: {response.status_code}")

        if response.status_code == 200:
            result = response.json()
            content = result['choices'][0]['message']['content']

            print("\n[SUCCESS] 성공!")
            print(f"\n생성된 텍스트:")
            print("-" * 60)
            print(content)
            print("-" * 60)

            # 추가 정보
            print(f"\n생성 정보:")
            print(f"  - 사용된 토큰: {result.get('usage', {}).get('total_tokens', 'N/A')}")
            print(f"  - 모델: {result.get('model', 'N/A')}")

        else:
            print(f"[FAILED] 실패!")
            print(f"에러 응답: {response.text}")

    except Exception as e:
        print(f"[ERROR] 요청 중 에러 발생: {str(e)}")


def test_image_recognition():
    """google/gemma-3-27b-it:free 모델로 이미지 인식 테스트"""
    print("\n" + "="*60)
    print("[TEST 2] 이미지 인식 (google/gemma-3-27b-it:free)")
    print("="*60)

    # 테스트용 이미지 URL (공개 이미지)
    image_url = "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Good_Food_Display_-_NCI_Visuals_Online.jpg/1024px-Good_Food_Display_-_NCI_Visuals_Online.jpg"

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    data = {
        "model": "google/gemma-3-27b-it:free",
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": image_url
                        }
                    },
                    {
                        "type": "text",
                        "text": "이 이미지에 무엇이 보이나요? 이미지에 있는 모든 음식 항목을 나열해 주세요."
                    }
                ]
            }
        ],
        "max_tokens": 500,
        "temperature": 0.7
    }

    try:
        print("\n요청 정보:")
        print(f"  - 모델: google/gemma-3-27b-it:free")
        print(f"  - 이미지 URL: (공개 이미지)")
        print(f"  - 질문: '이 이미지에 무엇이 보이나요? 이미지에 있는 모든 음식 항목을 나열해 주세요.'")
        print(f"  - Max tokens: 500")

        response = requests.post(API_URL, headers=headers, json=data, timeout=30)

        print(f"\n응답 상태: {response.status_code}")

        if response.status_code == 200:
            result = response.json()
            content = result['choices'][0]['message']['content']

            print("\n[SUCCESS] 성공!")
            print(f"\n이미지 인식 결과:")
            print("-" * 60)
            print(content)
            print("-" * 60)

            # 추가 정보
            print(f"\n인식 정보:")
            print(f"  - 사용된 토큰: {result.get('usage', {}).get('total_tokens', 'N/A')}")
            print(f"  - 모델: {result.get('model', 'N/A')}")

        else:
            print(f"[FAILED] 실패!")
            print(f"에러 응답: {response.text}")

    except Exception as e:
        print(f"[ERROR] 요청 중 에러 발생: {str(e)}")


def test_vision_gemma_with_base64():
    """Base64로 인코딩된 이미지로 테스트 (선택사항)"""
    print("\n" + "="*60)
    print("[TEST 3] 이미지 인식 (Base64 이미지)")
    print("="*60)

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    # 간단한 1x1 빨간 픽셀 이미지 (Base64)
    simple_image_base64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8DwHwAFBQIAX8jx0gAAAABJRU5ErkJggg=="

    data = {
        "model": "google/gemma-3-27b-it:free",
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/png;base64,{simple_image_base64}"
                        }
                    },
                    {
                        "type": "text",
                        "text": "이 이미지는 어떤 색상인가요?"
                    }
                ]
            }
        ],
        "max_tokens": 200,
        "temperature": 0.7
    }

    try:
        print("\n요청 정보:")
        print(f"  - 모델: google/gemma-3-27b-it:free")
        print(f"  - 이미지: Base64 인코딩된 간단한 이미지")
        print(f"  - 질문: '이 이미지는 어떤 색상인가요?'")

        response = requests.post(API_URL, headers=headers, json=data, timeout=30)

        print(f"\n응답 상태: {response.status_code}")

        if response.status_code == 200:
            result = response.json()
            content = result['choices'][0]['message']['content']

            print("\n[SUCCESS] 성공!")
            print(f"\n응답:")
            print(content)

        else:
            print(f"[FAILED] 실패!")
            print(f"에러 응답: {response.text}")

    except Exception as e:
        print(f"[ERROR] 요청 중 에러 발생: {str(e)}")


if __name__ == "__main__":
    print("\n[START] Together AI API 테스트 시작\n")

    # 테스트 1: 텍스트 생성
    test_text_generation()

    # 테스트 2: 이미지 인식 (URL 기반)
    test_image_recognition()

    # 테스트 3: Base64 이미지 (선택사항)
    test_vision_gemma_with_base64()

    print("\n" + "="*60)
    print("[COMPLETE] 모든 테스트 완료!")
    print("="*60 + "\n")
