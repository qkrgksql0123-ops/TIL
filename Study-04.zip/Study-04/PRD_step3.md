# PRD Step 3: 사용자 프로필 및 레시피 저장

## 개요

사용자 계정 관리 및 레시피 저장/관리 기능을 추가합니다.
사용자의 즐겨찾기 레시피, 조리 기록, 개인 설정을 저장하고 관리합니다.

## 목표

- 사용자 계정 생성 및 로그인
- 선호하는 레시피 저장 및 관리
- 조리 기록 추적
- 개인화된 레시피 추천
- 사용자 데이터 보안 보장

## 주요 기능

### 1. 사용자 인증

#### 회원가입
- **필수 정보**:
  - 이메일 (unique)
  - 비밀번호 (8자 이상, 대소문자+숫자 포함)
  - 닉네임 (2-20자)

- **선택 정보**:
  - 프로필 사진
  - 나이 / 성별
  - 식단 선호도 (채식주의, 비건 등)
  - 알레르기 정보
  - 싫어하는 음식

#### 로그인
- 이메일 + 비밀번호
- 토큰 기반 인증 (JWT)
- "기억하기" 옵션 (30일)
- 소셜 로그인 (선택사항): Google, GitHub

#### 비밀번호 관리
- 비밀번호 변경
- 비밀번호 재설정 (이메일 인증)
- 로그아웃

### 2. 사용자 프로필 관리

#### 프로필 정보
```json
{
  "user_id": "user_12345",
  "email": "user@example.com",
  "nickname": "요리사",
  "profile_image": "url",
  "bio": "음식을 사랑하는 사람입니다",
  "created_at": "2024-04-07T10:00:00Z",
  "preferences": {
    "difficulty": "중간",
    "time": "30분",
    "cuisines": ["한식", "양식"],
    "allergies": ["견과류", "조개류"],
    "dislikes": ["매운맛", "버터"]
  }
}
```

#### 프로필 수정
- 닉네임, 프로필 사진, 소개 수정
- 식단 선호도 업데이트
- 알레르기 정보 관리

### 3. 레시피 저장 관리

#### 저장된 레시피
- **저장 정보**:
  - 원본 레시피 ID
  - 저장 날짜
  - 사용자 메모
  - 개인 평점 (1-5점)
  - 조리 시도 여부

- **저장 형식**:
  ```json
  {
    "saved_id": "saved_12345",
    "user_id": "user_12345",
    "recipe_id": "recipe_56789",
    "recipe_title": "계란 브로콜리 볶음",
    "saved_at": "2024-04-07T10:45:00Z",
    "personal_rating": 5,
    "notes": "너무 맛있었어요! 다음엔 마늘을 더 넣어야겠어요",
    "cooked_count": 2,
    "last_cooked": "2024-04-05T18:30:00Z"
  }
  ```

#### 저장 기능
- 레시피 상세 보기 화면에서 "❤ 저장" 클릭
- 저장된 레시피 목록 조회
- 저장 취소 (삭제)
- 저장된 레시피 순서 정렬 (최신순, 평점순, 조리빈도순)

### 4. 조리 기록 추적

#### 조리 기록
- **기록 정보**:
  - 조리한 레시피명
  - 조리 날짜 및 시간
  - 소요 시간
  - 결과 평점
  - 후기/메모

- **기록 형식**:
  ```json
  {
    "cook_log_id": "log_12345",
    "user_id": "user_12345",
    "recipe_id": "recipe_56789",
    "recipe_title": "계란 브로콜리 볶음",
    "cooked_at": "2024-04-05T18:30:00Z",
    "cooking_time": "15분",
    "rating": 5,
    "review": "정말 맛있었어요!",
    "ingredients_changed": false
  }
  ```

#### 조리 기록 관리
- 조리 완료 후 기록 추가
- 기록 수정/삭제
- 월별 조리 통계 표시
- 가장 자주 조리한 레시피 표시

### 5. 개인화된 추천

#### 추천 알고리즘
- 저장된 레시피 기반 추천
- 조리 기록 기반 추천
- 사용자 선호도 기반 추천
- 계절 재료 기반 추천

#### 추천 피드
- "당신을 위한 추천" 섹션
- "인기 있는 레시피" 섹션
- "최근 조리한 요리 비슷한 레시피" 섹션

### 6. 대시보드

#### 홈 대시보드
```
┌──────────────────────────────────┐
│  🏠 안녕하세요, {닉네임}님!       │
├──────────────────────────────────┤
│                                  │
│ 📊 이달 통계                      │
│ - 조리한 요리: 5개                │
│ - 새로운 레시피 저장: 12개        │
│ - 평균 평점: 4.3점               │
│                                  │
│ ❤️ 최근 저장한 레시피             │
│ [레시피 1] [레시피 2] [레시피 3]  │
│                                  │
│ 👨‍🍳 당신을 위한 추천              │
│ [추천 1] [추천 2] [추천 3]        │
│                                  │
│ 📅 조리 기록                      │
│ 최근 조리: 2024.04.05            │
│ 이번 달 조리: 5회                │
│                                  │
│ [레시피 분석] [설정]  [로그아웃]  │
└──────────────────────────────────┘
```

## 사용자 흐름

### 첫 방문 사용자
1. 홈페이지 접속
2. "회원가입" 버튼 클릭
3. 회원가입 정보 입력
4. 이메일 인증 (옵션)
5. Step 1로 진행

### 기존 사용자
1. 로그인 페이지 접속
2. 이메일/비밀번호 입력 → 로그인
3. 대시보드 화면 표시
4. Step 1 또는 저장된 레시피 조회

### 레시피 저장 플로우
1. Step 2에서 레시피 상세 보기
2. "❤ 저장" 버튼 클릭
3. 저장 확인 메시지
4. "저장된 레시피" 메뉴에서 조회 가능

### 조리 기록 추가 플로우
1. 레시피 조리 후
2. "조리 완료" 버튼 클릭
3. 평점/후기 입력 팝업
4. 제출 완료

## 기술 사양

### 데이터베이스 스키마

#### Users 테이블
```sql
CREATE TABLE users (
  user_id VARCHAR(36) PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  nickname VARCHAR(50) NOT NULL,
  profile_image VARCHAR(500),
  bio TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  is_active BOOLEAN DEFAULT TRUE
);
```

#### User Preferences 테이블
```sql
CREATE TABLE user_preferences (
  id VARCHAR(36) PRIMARY KEY,
  user_id VARCHAR(36) FOREIGN KEY,
  difficulty VARCHAR(20),
  preferred_time VARCHAR(20),
  cuisines JSON,
  allergies JSON,
  dislikes JSON,
  created_at TIMESTAMP,
  updated_at TIMESTAMP
);
```

#### Saved Recipes 테이블
```sql
CREATE TABLE saved_recipes (
  saved_id VARCHAR(36) PRIMARY KEY,
  user_id VARCHAR(36) FOREIGN KEY,
  recipe_id VARCHAR(36) NOT NULL,
  recipe_data JSON,
  personal_rating INT,
  notes TEXT,
  saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  cooked_count INT DEFAULT 0
);
```

#### Cook Logs 테이블
```sql
CREATE TABLE cook_logs (
  log_id VARCHAR(36) PRIMARY KEY,
  user_id VARCHAR(36) FOREIGN KEY,
  recipe_id VARCHAR(36) NOT NULL,
  cooked_at TIMESTAMP,
  cooking_time VARCHAR(50),
  rating INT,
  review TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### API 엔드포인트

#### 인증
```
POST /api/auth/signup
POST /api/auth/login
POST /api/auth/logout
POST /api/auth/refresh-token
POST /api/auth/reset-password
```

#### 프로필
```
GET /api/user/profile
PUT /api/user/profile
PUT /api/user/preferences
GET /api/user/preferences
```

#### 저장된 레시피
```
POST /api/user/saved-recipes (레시피 저장)
GET /api/user/saved-recipes (저장된 레시피 목록)
DELETE /api/user/saved-recipes/{saved_id} (저장 취소)
GET /api/user/saved-recipes/{saved_id} (상세 조회)
PUT /api/user/saved-recipes/{saved_id} (메모/평점 수정)
```

#### 조리 기록
```
POST /api/user/cook-logs (기록 추가)
GET /api/user/cook-logs (기록 목록)
GET /api/user/cook-logs/stats (월별 통계)
DELETE /api/user/cook-logs/{log_id} (기록 삭제)
```

#### 추천
```
GET /api/user/recommendations (개인화 추천)
GET /api/recipes/popular (인기 레시피)
```

### 백엔드 구조
- 사용자 관리: User Service
- 인증: Auth Service (JWT)
- 데이터 저장소: Database (PostgreSQL/MySQL)
- 캐싱: Redis (세션, 추천)

## UI/UX 설계

### 회원가입 화면
```
┌──────────────────────────────────┐
│      회원가입                     │
├──────────────────────────────────┤
│                                  │
│ 이메일                           │
│ [________________]               │
│                                  │
│ 비밀번호 (8자 이상)             │
│ [________________]               │
│ ✓ 대문자 포함                    │
│ ✓ 숫자 포함                      │
│                                  │
│ 비밀번호 확인                    │
│ [________________]               │
│                                  │
│ 닉네임                           │
│ [________________]               │
│                                  │
│ [동의] 서비스 약관에 동의합니다  │
│                                  │
│ [회원가입]                       │
│                                  │
│ 이미 계정이 있으신가요? [로그인] │
└──────────────────────────────────┘
```

### 저장된 레시피 목록
```
┌──────────────────────────────────┐
│   ❤ 저장된 레시피 (12개)          │
├──────────────────────────────────┤
│                                  │
│ [정렬순서: 최신순 ▼]             │
│ [필터: 모든 요리 ▼]              │
│                                  │
│ ┌─ 계란 브로콜리 볶음 ──────────┐
│ │ ⭐ 5/5  저장일: 2024.04.05    │
│ │ 나의 메모: 너무 맛있었어요!   │
│ │ 조리 횟수: 2회                │
│ │ [조리기록] [삭제]              │
│ └────────────────────────────────┘
│
│ ...
│
└──────────────────────────────────┘
```

### 조리 기록 팝업
```
┌──────────────────────────────────┐
│    조리 완료!                     │
├──────────────────────────────────┤
│                                  │
│ 계란 브로콜리 볶음               │
│                                  │
│ 소요 시간                        │
│ [________________] 분            │
│                                  │
│ 평점                             │
│ ⭐ ⭐ ⭐ ⭐ ⭐ (5점)             │
│                                  │
│ 후기                             │
│ [_____________________]          │
│ [_____________________]          │
│                                  │
│ [취소]  [저장]                   │
└──────────────────────────────────┘
```

## 보안 고려사항

### 데이터 보안
- 비밀번호 해싱 (bcrypt)
- JWT 토큰 기반 인증
- HTTPS 통신
- CORS 정책 적용

### 개인정보 보호
- 민감 정보 암호화 저장
- 로그인 기록 추적
- 데이터 삭제 정책 (계정 삭제 시)
- GDPR 준수

### 세션 관리
- 토큰 만료 시간: 24시간
- 리프레시 토큰: 30일
- "로그아웃" 시 토큰 무효화

## 오류 처리

### 가능한 오류
1. **이메일 중복**
   - 메시지: "이미 사용 중인 이메일입니다"

2. **약한 비밀번호**
   - 메시지: "비밀번호는 8자 이상이며 대문자, 숫자를 포함해야 합니다"

3. **로그인 실패**
   - 메시지: "이메일 또는 비밀번호가 올바르지 않습니다"

4. **토큰 만료**
   - 자동 리프레시 시도
   - 실패 시 재로그인 요청

5. **저장 실패**
   - 메시지: "저장에 실패했습니다. 다시 시도해 주세요"

## 성공 지표

- 회원가입 완료율: 85% 이상
- 로그인 유지율: 75% 이상
- 저장된 레시피 수: 평균 10개 이상
- 조리 기록 추적률: 60% 이상
- 사용자 만족도: 4점 이상 (5점 만점)

## 기술 스택

- **프론트엔드**: React/Vue.js
- **백엔드**: Flask/FastAPI (Python)
- **데이터베이스**: PostgreSQL / MySQL
- **인증**: JWT (json-web-token)
- **보안**: bcrypt, HTTPS
- **캐싱**: Redis
- **파일 저장소**: AWS S3 (프로필 사진)

## 마일스톤

- **완료 기준**:
  - 회원가입/로그인 구현
  - 사용자 프로필 관리
  - 데이터베이스 설계 및 구축
  - 저장된 레시피 기능
  - 조리 기록 기능
  - 개인화 추천 알고리즘
  - 보안 검증
  - 사용자 테스트

## 향후 계획

### Phase 2 확장 기능
- 커뮤니티 기능 (레시피 공유, 평가)
- 소셜 네트워킹 (팔로우, 팀 관리)
- 영상 조리 튜토리얼
- 영양 분석 상세 정보
- 쇼핑 리스트 생성
- 주간 식단 계획

### Phase 3 고도화
- 음성 명령 기능
- 모바일 앱
- 오프라인 모드
- AI 기반 상세 추천
- 냉장고 IoT 연동
