#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Local Together AI API Server Test Suite
"""

import requests
import json
import time

# Server configuration
API_BASE_URL = "http://localhost:5000"

def test_health():
    """Test health endpoint"""
    print("\n" + "="*70)
    print("[TEST 0] Server Health Check")
    print("="*70)

    try:
        response = requests.get(f"{API_BASE_URL}/health", timeout=5)
        print(f"Response Status: {response.status_code}")

        if response.status_code == 200:
            data = response.json()
            print("\n[SUCCESS] Server is running!")
            print(f"  - Status: {data['status']}")
            print(f"  - API Key Loaded: {data['api_key_loaded']}")
            print(f"  - Text Model: {data['text_model']}")
            print(f"  - Image Model: {data['image_model']}")
            return True
        else:
            print(f"[FAILED] Status Code: {response.status_code}")
            return False

    except Exception as e:
        print(f"[ERROR] {str(e)}")
        return False


def test_text_generation():
    """Test text generation endpoint"""
    print("\n" + "="*70)
    print("[TEST 1] Text Generation (qwen/qwen3.6-plus:free)")
    print("="*70)

    payload = {
        "prompt": "What is artificial intelligence? Please explain it briefly in English.",
        "max_tokens": 300,
        "temperature": 0.7
    }

    try:
        print("\nRequest:")
        print(f"  - Endpoint: POST /api/generate-text")
        print(f"  - Prompt: {payload['prompt'][:50]}...")
        print(f"  - Max tokens: {payload['max_tokens']}")

        response = requests.post(
            f"{API_BASE_URL}/api/generate-text",
            json=payload,
            timeout=30
        )

        print(f"\nResponse Status: {response.status_code}")

        if response.status_code == 200:
            data = response.json()

            if data['success']:
                print("\n[SUCCESS] Text Generation Test Passed!")
                print(f"\nModel: {data['model']}")
                print(f"\nGenerated Text:")
                print("-" * 70)
                print(data['generated_text'])
                print("-" * 70)

                print(f"\nToken Usage:")
                print(f"  - Prompt tokens: {data['usage']['prompt_tokens']}")
                print(f"  - Completion tokens: {data['usage']['completion_tokens']}")
                print(f"  - Total tokens: {data['usage']['total_tokens']}")

                return True
            else:
                print(f"[FAILED] {data['error']}")
                return False
        else:
            print(f"[FAILED] Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return False

    except Exception as e:
        print(f"[ERROR] {str(e)}")
        return False


def test_image_recognition():
    """Test image recognition endpoint"""
    print("\n" + "="*70)
    print("[TEST 2] Image Recognition (google/gemma-3-27b-it:free)")
    print("="*70)

    payload = {
        "image_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Good_Food_Display_-_NCI_Visuals_Online.jpg/1024px-Good_Food_Display_-_NCI_Visuals_Online.jpg",
        "question": "What can you see in this image? Please list all the food items visible.",
        "max_tokens": 300,
        "temperature": 0.7
    }

    try:
        print("\nRequest:")
        print(f"  - Endpoint: POST /api/recognize-image")
        print(f"  - Image: Wikipedia food image")
        print(f"  - Question: {payload['question'][:50]}...")
        print(f"  - Max tokens: {payload['max_tokens']}")

        response = requests.post(
            f"{API_BASE_URL}/api/recognize-image",
            json=payload,
            timeout=30
        )

        print(f"\nResponse Status: {response.status_code}")

        if response.status_code == 200:
            data = response.json()

            if data['success']:
                print("\n[SUCCESS] Image Recognition Test Passed!")
                print(f"\nModel: {data['model']}")
                print(f"Image Source: {data['image_source']}")
                print(f"\nRecognition Result:")
                print("-" * 70)
                print(data['recognition_result'])
                print("-" * 70)

                print(f"\nToken Usage:")
                print(f"  - Prompt tokens: {data['usage']['prompt_tokens']}")
                print(f"  - Completion tokens: {data['usage']['completion_tokens']}")
                print(f"  - Total tokens: {data['usage']['total_tokens']}")

                return True
            else:
                print(f"[FAILED] {data['error']}")
                return False
        else:
            print(f"[FAILED] Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return False

    except Exception as e:
        print(f"[ERROR] {str(e)}")
        return False


def test_image_with_base64():
    """Test image recognition with base64 image"""
    print("\n" + "="*70)
    print("[TEST 3] Image Recognition with Base64 Image")
    print("="*70)

    # Simple red pixel PNG in base64
    red_pixel_base64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/8/wHwAFBQIAX8jx0gAAAABJRU5ErkJggg=="

    payload = {
        "image_base64": red_pixel_base64,
        "question": "What color is this image?",
        "max_tokens": 100,
        "temperature": 0.7
    }

    try:
        print("\nRequest:")
        print(f"  - Endpoint: POST /api/recognize-image")
        print(f"  - Image: Base64 encoded")
        print(f"  - Question: {payload['question']}")
        print(f"  - Max tokens: {payload['max_tokens']}")

        response = requests.post(
            f"{API_BASE_URL}/api/recognize-image",
            json=payload,
            timeout=30
        )

        print(f"\nResponse Status: {response.status_code}")

        if response.status_code == 200:
            data = response.json()

            if data['success']:
                print("\n[SUCCESS] Base64 Image Recognition Test Passed!")
                print(f"\nModel: {data['model']}")
                print(f"Image Source: {data['image_source']}")
                print(f"\nRecognition Result:")
                print("-" * 70)
                print(data['recognition_result'])
                print("-" * 70)

                return True
            else:
                print(f"[FAILED] {data['error']}")
                return False
        else:
            print(f"[FAILED] Status Code: {response.status_code}")
            print(f"Response: {response.text}")
            return False

    except Exception as e:
        print(f"[ERROR] {str(e)}")
        return False


def test_models_endpoint():
    """Test models endpoint"""
    print("\n" + "="*70)
    print("[TEST 4] Get Available Models")
    print("="*70)

    try:
        print("\nRequest:")
        print(f"  - Endpoint: GET /api/models")

        response = requests.get(f"{API_BASE_URL}/api/models", timeout=5)
        print(f"\nResponse Status: {response.status_code}")

        if response.status_code == 200:
            data = response.json()
            print("\n[SUCCESS] Models Endpoint Test Passed!")
            print(f"\nAvailable Models:")
            print(f"  - Text Generation: {data['text_generation']}")
            print(f"  - Image Recognition: {data['image_recognition']}")
            return True
        else:
            print(f"[FAILED] Status Code: {response.status_code}")
            return False

    except Exception as e:
        print(f"[ERROR] {str(e)}")
        return False


def main():
    print("\n" + "="*70)
    print("LOCAL TOGETHER AI API SERVER TEST SUITE")
    print("="*70)
    print(f"API Base URL: {API_BASE_URL}")

    # Run tests
    results = {}

    results['health'] = test_health()
    if not results['health']:
        print("\n[ERROR] Server is not running. Cannot continue tests.")
        return False

    results['models'] = test_models_endpoint()
    results['text_generation'] = test_text_generation()
    results['image_recognition'] = test_image_recognition()
    results['base64_image'] = test_image_with_base64()

    # Summary
    print("\n" + "="*70)
    print("TEST SUMMARY")
    print("="*70)

    passed = sum(1 for v in results.values() if v)
    total = len(results)

    for test_name, result in results.items():
        status = "[PASS]" if result else "[FAIL]"
        print(f"  {status} {test_name}")

    print(f"\nTotal: {passed}/{total} tests passed")
    print("="*70 + "\n")

    return all(results.values())


if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)
